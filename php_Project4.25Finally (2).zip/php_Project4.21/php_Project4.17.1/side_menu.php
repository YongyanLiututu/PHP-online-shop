<!DOCTYPE html>
<html>
<head>
    <title>Online Grocery Store</title>
</head>
<body>
<h2>Side Menu</h2>
<ul>
    <li><a href="main_content.php" target="main_content">Home</a></li>
    <li><a href="products.php" target="main_content">Products</a></li>
    <li><a href="cart.php" target="main_content">Cart</a></li>
    <li><a href="checkout.php" target="main_content">Checkout</a></li>
</ul>
</body>
</html>
