// 创建购物车表格
var table = document.createElement("table");
table.style.borderCollapse = "collapse";
table.style.width = "100%";

// 创建表头行
var headerRow = table.insertRow();

// 创建表头单元格并设置样式和内容
var th1 = document.createElement("th");
th1.style.padding = "10px";
th1.style.border = "1px solid #ddd";
th1.textContent = "商品编号";

var th2 = document.createElement("th");
th2.style.padding = "10px";
th2.style.border = "1px solid #ddd";
th2.textContent = "商品名称";

var th3 = document.createElement("th");
th3.style.padding = "10px";
th3.style.border = "1px solid #ddd";
th3.textContent = "数量";

var th4 = document.createElement("th");
th4.style.padding = "10px";
th4.style.border = "1px solid #ddd";
th4.textContent = "单价";

var th5 = document.createElement("th");
th5.style.padding = "10px";
th5.style.border = "1px solid #ddd";
th5.textContent = "小计";

headerRow.appendChild(th1);
headerRow.appendChild(th2);
headerRow.appendChild(th3);
headerRow.appendChild(th4);
headerRow.appendChild(th5);

// 遍历购物车项并创建表格行
for (var i in cartData) {
if (i !== "") {
var cartItem = cartData[i];
var product = getProductById(cartItem.id);
var price = product.price;
var quantity = cartItem.quantity;
var total = price * quantity;

var row = table.insertRow();

var cell1 = row.insertCell();
cell1.style.border = "1px solid #ddd";
cell1.textContent = product.id;

var cell2 = row.insertCell();
cell2.style.border = "1px solid #ddd";
cell2.textContent = product.name;

var cell3 = row.insertCell();
cell3.style.border = "1px solid #ddd";
cell3.textContent = quantity;

var cell4 = row.insertCell();
cell4.style.border = "1px solid #ddd";
cell4.textContent = "$" + price.toFixed(2);

var cell5 = row.insertCell();
cell5.style.border = "1px solid #ddd";
cell5.textContent = "$" + total.toFixed(2);
}
}

// 将表格添加到页面中
var cartTable = document.getElementById("cart-table");
cartTable.innerHTML = "";
cartTable.appendChild(table);

// 根据商品 ID 获取商品信息
function getProductById(productId) {
// 这里需要根据商品 ID 查询商品信息，这里只是示例代码，假设商品信息已经存在
var products = {
1000: {
id: 1000,
name: "商品 1",
price: 10.99,
},
2000: {
id: 2000,
name: "商品 2",
price: 19.99,
},
2001: {
id: 2001,
name: "商品 3",
price: 15.99,
},
2002: {
id: 2002,
name: "商品 4",
price: 12.99,
},
4000: {
id: 4000,
name: "商品 5",
price: 8.99,
},
};
return
