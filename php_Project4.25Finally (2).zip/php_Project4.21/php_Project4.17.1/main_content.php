<!DOCTYPE html>
<html>
<head>
    <title>UTS Grocery Store</title>
</head>
<body>
<h2>Main Content</h2>
<p>Welcome to our online grocery store! Browse our products, add items to your cart, and proceed to checkout to complete
    your purchase.</p>
</body>
</html>

